/**
 * Экранная лупа (Screen Magnifier) — Service Worker (Manifest V3)
 *
 * Отвечает только за управление состоянием:
 *  - активация/деактивация лупы (горячая клавиша, клик по иконке);
 *  - динамическое внедрение content script + css через chrome.scripting;
 *  - захват видимой области вкладки по запросу от content script
 *    (chrome.tabs.captureVisibleTab доступен только из фоновых скриптов);
 *  - смена иконки (синяя/зелёная) и бейджа с уровнем зума.
 */

'use strict';

// Состояние лупы по вкладкам: tabId -> true/false
const activeTabs = new Set();

// Путь к контентным файлам относительно корня расширения
const CONTENT_SCRIPT = 'content/magnifier.js';
const CONTENT_CSS = 'content/magnifier.css';

/* ------------------------------------------------------------------ */
/* Активация / деактивация                                             */
/* ------------------------------------------------------------------ */

/**
 * Инжектит content script и стили в активную вкладку, затем
 * отправляет команду на переключение состояния лупы.
 * @param {number} tabId
 */
async function toggleMagnifier(tabId) {
  try {
    // Динамическое внедрение (см. ТЗ п. 5.5) — повторное внедрение
    // безопасно: magnifier.js сам защищён от двойной инициализации.
    await chrome.scripting.insertCSS({ target: { tabId }, files: [CONTENT_CSS] });
    await chrome.scripting.executeScript({ target: { tabId }, files: [CONTENT_SCRIPT] });

    const isActive = activeTabs.has(tabId);
    if (isActive) {
      activeTabs.delete(tabId);
    } else {
      activeTabs.add(tabId);
    }

    await chrome.tabs.sendMessage(tabId, { type: 'TOGGLE_MAGNIFIER', enable: !isActive });
    updateActionUi(tabId, !isActive);
  } catch (err) {
    // Ограничения Chrome: chrome://, edge://, Web Store, PDF-вьювер и т.п.
    console.warn('Не удалось активировать лупу на этой странице:', err.message);
  }
}

/**
 * Обновляет иконку действия и бейдж (уровень зума) для вкладки.
 * @param {number} tabId
 * @param {boolean} active
 * @param {string} [zoomText] текст бейджа, например "2x"
 */
function updateActionUi(tabId, active, zoomText) {
  const suffix = active ? 'green' : 'blue';
  chrome.action.setIcon({
    tabId,
    path: {
      '16': `icons/icon16_${suffix}.png`,
      '48': `icons/icon48_${suffix}.png`,
      '128': `icons/icon128_${suffix}.png`
    }
  }).catch(() => {});

  if (active && zoomText) {
    chrome.action.setBadgeText({ tabId, text: zoomText }).catch(() => {});
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#00C878' }).catch(() => {});
  } else if (!active) {
    chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
  }
}

/* ------------------------------------------------------------------ */
/* Слушатели событий                                                   */
/* ------------------------------------------------------------------ */

// Горячая клавиша Ctrl+Shift+M (см. manifest.json → commands)
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-magnifier') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id !== undefined) toggleMagnifier(tab.id);
});

// Клик по иконке расширения → показать/скрыть лупу (popup не используется)
chrome.action.onClicked.addListener((tab) => {
  if (tab.id !== undefined) toggleMagnifier(tab.id);
});

/**
 * Сообщения от content script:
 *  - CAPTURE        — запрос кадра видимой области вкладки;
 *  - STATE          — синхронизация иконки/бейджа при изменении состояния;
 *  - ZOOM_BADGE     — обновление бейджа с текущим зумом;
 *  - DEACTIVATED    — лупа скрыта со стороны страницы.
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab && sender.tab.id;

  switch (msg && msg.type) {
    case 'CAPTURE': {
      // Асинхронный ответ требует return true.
      // captureVisibleTab возвращает data URL (image/png или image/jpeg).
      const format = (msg.format === 'jpeg') ? 'jpeg' : 'png';
      chrome.tabs.captureVisibleTab(sender.tab.windowId, { format })
        .then(dataUrl => sendResponse({ ok: true, dataUrl }))
        .catch(err => sendResponse({ ok: false, error: String(err && err.message || err) }));
      return true;
    }

    case 'ZOOM_BADGE': {
      if (tabId !== undefined && activeTabs.has(tabId)) {
        updateActionUi(tabId, true, msg.text || '');
      }
      break;
    }

    case 'DEACTIVATED': {
      if (tabId !== undefined) {
        activeTabs.delete(tabId);
        updateActionUi(tabId, false);
      }
      break;
    }

    case 'STATE': {
      if (tabId !== undefined) updateActionUi(tabId, !!msg.active, msg.zoomText);
      break;
    }

    default:
      break;
  }
  // Синхронный ответ не нужен для остальных типов сообщений
});

// Убираем состояние при закрытии вкладки
chrome.tabs.onRemoved.addListener((tabId) => {
  activeTabs.delete(tabId);
});

// При перезагрузке/навигации страницы лупа исчезает — сбрасываем состояние
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && activeTabs.has(tabId)) {
    activeTabs.delete(tabId);
    updateActionUi(tabId, false);
  }
});
