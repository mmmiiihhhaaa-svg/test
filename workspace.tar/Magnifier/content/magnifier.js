/**
 * Экранная лупа (Screen Magnifier) — content script.
 *
 * Реализация по ТЗ п. 5.2: Canvas + chrome.tabs.captureVisibleTab.
 *  - Overlay-элемент (div > canvas) следует за курсором (requestAnimationFrame);
 *  - захват экрана троттлится до ~30fps, отрисовка — 60fps;
 *  - зум регулируется колесиком с модификатором (по умолчанию Shift),
 *    яркость — колесиком с Alt+Shift (модификаторы настраиваются);
 *  - лупа не перехватывает клики (pointer-events: none), клик по странице
 *    и mouseleave окна скрывают её;
 *  - настройки читаются из chrome.storage.sync (фоллбэк local) и
 *    применяются мгновенно через storage.onChanged.
 */

'use strict';

(() => {
  // Защита от двойного внедрения (service worker может инжектить повторно)
  if (window.__screenMagnifierLoaded__) {
    return;
  }
  window.__screenMagnifierLoaded__ = true;

  /* ---------------------------------------------------------------- */
  /* Настройки по умолчанию (ТЗ п. 4)                                  */
  /* ---------------------------------------------------------------- */
  const DEFAULTS = {
    // Внешний вид
    shape: 'circle',            // 'circle' | 'square'
    size: 256,                  // px, 50..800
    borderEnabled: true,
    borderColor: '#00AAFF',
    borderWidth: 2,             // px, 1..10

    // Зум
    zoomMin: 1.5,               // от 1.1
    zoomMax: 5.0,               // до 10.0
    zoomStep: 0.25,             // 0.1..1.0
    zoomModifier: 'Shift',      // Shift | Ctrl | Alt | None

    // Яркость
    brightnessMin: 0.5,         // от 0.1
    brightnessMax: 2.0,         // до 3.0
    brightnessStep: 0.1,        // 0.05..0.5
    brightnessModifiers: 'Alt+Shift', // фиксированная комбинация по умолчанию;
                                      // составные значения собираются ниже

    // Качество
    smoothing: true,

    // Прочее
    showZoomIndicator: true,
    captureFormat: 'jpeg'       // jpeg быстрее декодируется при 30fps
  };

  // Ограничения для клампинга (ТЗ п. 4)
  const LIMITS = {
    size: [50, 800],
    borderWidth: [1, 10],
    zoomMin: [1.1, 10],
    zoomMax: [1.1, 10],
    zoomStep: [0.1, 1.0],
    brightnessMin: [0.1, 3],
    brightnessMax: [0.1, 3],
    brightnessStep: [0.05, 0.5]
  };

  /** @type {typeof DEFAULTS} */
  let settings = Object.assign({}, DEFAULTS);

  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  const clampTo = (v, key) => clamp(v, LIMITS[key][0], LIMITS[key][1]);

  /* ---------------------------------------------------------------- */
  /* Состояние лупы                                                    */
  /* ---------------------------------------------------------------- */
  let enabled = false;          // лупа активна (видна)
  let zoom = settings.zoomMin;
  let brightness = 1.0;

  // Позиция курсора (обновляется в mousemove, читается в rAF)
  let mouseX = 0;
  let mouseY = 0;
  let cursorInsideWindow = true;

  // Кадр захвата
  let capturedImage = new Image();
  let captureInFlight = false;
  let lastCaptureTime = 0;
  const CAPTURE_INTERVAL_MS = 1000 / 30; // ~30fps (ТЗ п. 5.3)

  let rafId = 0;
  let pendingRender = false;    // нужен новый захват после завершения текущего

  /* ---------------------------------------------------------------- */
  /* DOM: overlay лупы                                                 */
  /* ---------------------------------------------------------------- */
  const root = document.createElement('div');
  root.id = 'screen-magnifier-root';
  root.hidden = true;

  const lens = document.createElement('div');
  lens.className = 'sm-lens';

  const canvas = document.createElement('canvas');
  canvas.className = 'sm-canvas';

  const zoomLabel = document.createElement('div');
  zoomLabel.className = 'sm-zoom-label';

  const brightBarWrap = document.createElement('div');
  brightBarWrap.className = 'sm-brightness-bar';
  const brightBarFill = document.createElement('div');
  brightBarFill.className = 'sm-brightness-fill';
  brightBarWrap.appendChild(brightBarFill);

  const message = document.createElement('div');
  message.className = 'sm-message';
  message.hidden = true;

  lens.appendChild(canvas);
  lens.appendChild(zoomLabel);
  lens.appendChild(brightBarWrap);
  lens.appendChild(message);
  root.appendChild(lens);

  /* ---------------------------------------------------------------- */
  /* Применение настроек к DOM                                         */
  /* ---------------------------------------------------------------- */
  function applySettingsToDom() {
    const s = settings;
    const size = clampTo(s.size, 'size');

    lens.style.width = size + 'px';
    lens.style.height = size + 'px';
    lens.style.borderRadius = (s.shape === 'circle') ? '50%' : '8px';

    if (s.borderEnabled) {
      lens.style.boxShadow = `0 0 0 ${clampTo(s.borderWidth, 'borderWidth')}px ${s.borderColor}`;
    } else {
      lens.style.boxShadow = 'none';
    }

    // Размер буфера canvas = размер лупы * devicePixelRatio для резкости
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);
    canvas.style.width = size + 'px';
    canvas.style.height = size + 'px';

    // Сглаживание in/out (ТЗ п. 2.4 / 4.5)
    canvas.classList.toggle('sm-pixelated', !s.smoothing);

    zoomLabel.style.display = s.showZoomIndicator ? '' : 'none';
    updateIndicators();
  }

  /* ---------------------------------------------------------------- */
  /* Индикаторы: зум "2.0x" и прогресс-бар яркости                     */
  /* ---------------------------------------------------------------- */
  function formatZoom(z) {
    return z.toFixed(z % 1 === 0 ? 0 : 1) + 'x';
  }

  function updateIndicators() {
    zoomLabel.textContent = formatZoom(zoom);

    const bMin = clampTo(settings.brightnessMin, 'brightnessMin');
    const bMax = clampTo(settings.brightnessMax, 'brightnessMax');
    const ratio = bMax > bMin ? (brightness - bMin) / (bMax - bMin) : 0;
    brightBarFill.style.width = (clamp(ratio, 0, 1) * 100).toFixed(1) + '%';
    brightBarWrap.title = 'Яркость: ' + brightness.toFixed(2);

    // Бейдж на иконке расширения с текущим уровнем зума (ТЗ п. 6)
    safeSendMessage({ type: 'ZOOM_BADGE', text: formatZoom(zoom) });
  }

  /** Пульсация границы при достижении лимита зума/яркости (ТЗ п. 2.2) */
  function pulseBorder() {
    lens.classList.remove('sm-pulse');
    // форсируем reflow, чтобы анимация перезапустилась
    void lens.offsetWidth;
    lens.classList.add('sm-pulse');
  }

  /* ---------------------------------------------------------------- */
  /* Коммуникация с service worker                                     */
  /* ---------------------------------------------------------------- */
  function safeSendMessage(msg) {
    try {
      chrome.runtime.sendMessage(msg);
    } catch (e) {
      // Расширение могло быть обновлено/удалено — молча игнорируем
    }
  }

  function requestCapture() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          { type: 'CAPTURE', format: settings.captureFormat },
          (resp) => {
            if (chrome.runtime.lastError || !resp || !resp.ok) {
              resolve({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message)
                || (resp && resp.error) || 'capture failed' });
            } else {
              resolve({ ok: true, dataUrl: resp.dataUrl });
            }
          }
        );
      } catch (e) {
        resolve({ ok: false, error: String(e) });
      }
    });
  }

  /* ---------------------------------------------------------------- */
  /* Захват и отрисовка                                                */
  /* ---------------------------------------------------------------- */

  /** Показывает сообщение внутри лупы (ошибки/предупреждения, ТЗ п. 5.6) */
  function showMessage(text) {
    message.textContent = text;
    message.hidden = false;
  }

  function hideMessage() {
    message.hidden = true;
  }

  /**
   * Цикл захвата: запрашивает кадр у service worker не чаще ~30fps,
   * если лупа видна, мышь двигается и курсор внутри окна.
   */
  async function captureLoop(now) {
    if (!enabled || !cursorInsideWindow) return;
    if (captureInFlight) {
      pendingRender = true; // доснимем сразу после текущего запроса
      return;
    }
    if (now - lastCaptureTime < CAPTURE_INTERVAL_MS && !pendingRender) return;

    captureInFlight = true;
    pendingRender = false;
    lastCaptureTime = now;

    const res = await requestCapture();
    captureInFlight = false;

    if (!res.ok) {
      // chrome:// страницы и т.п. — graceful degradation (ТЗ п. 5.6)
      showMessage('Захват экрана недоступен на этой странице');
      return;
    }
    hideMessage();

    const img = new Image();
    img.onload = () => {
      capturedImage = img;
      drawLens();
    };
    img.onerror = () => {
      showMessage('Ошибка обработки захваченного кадра');
    };
    img.src = res.dataUrl;
  }

  /**
   * Рисует увеличенную область кадра под курсором на canvas лупы.
   * Координаты CSS-пикселей переводятся в пиксели захвата (× devicePixelRatio).
   */
  function drawLens() {
    if (!capturedImage.width || !enabled) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const cw = canvas.width;   // px лупы с учётом dpr
    const ch = canvas.height;

    // Источник: квадрат вокруг курсора размером (лупа / zoom) в экранных px
    const srcSizeCss = (cw / dpr) / zoom;
    const srcSize = srcSizeCss * dpr;
    const sx = mouseX * dpr - srcSize / 2;
    const sy = mouseY * dpr - srcSize / 2;

    ctx.imageSmoothingEnabled = settings.smoothing;
    ctx.imageSmoothingQuality = 'high';

    ctx.clearRect(0, 0, cw, ch);

    // Круглая маска линзы
    ctx.save();
    if (settings.shape === 'circle') {
      ctx.beginPath();
      ctx.arc(cw / 2, ch / 2, cw / 2, 0, Math.PI * 2);
      ctx.clip();
    }

    // Границы источника ограничим кадром, чтобы не рисовать пустоту
    const clampedSx = clamp(sx, 0, Math.max(0, capturedImage.width - srcSize));
    const clampedSy = clamp(sy, 0, Math.max(0, capturedImage.height - srcSize));

    ctx.drawImage(
      capturedImage,
      clampedSx, clampedSy, srcSize, srcSize,
      0, 0, cw, ch
    );
    ctx.restore();

    // Яркость — CSS filter на canvas (ТЗ п. 5.2, пункт 4)
    canvas.style.filter = `brightness(${brightness})`;
  }

  /* ---------------------------------------------------------------- */
  /* Движение лупы (rAF, GPU-ускорение через translate3d)              */
  /* ---------------------------------------------------------------- */
  function positionLens() {
    const size = lens.offsetWidth || settings.size;
    const gap = 16; // смещение от курсора, чтобы он всегда был виден

    let x = mouseX + gap;
    let y = mouseY + gap;

    // Не выпускаем лупу за пределы вьюпорта
    if (x + size > window.innerWidth) x = mouseX - size - gap;
    if (y + size > window.innerHeight) y = mouseY - size - gap;
    x = Math.max(0, x);
    y = Math.max(0, y);

    lens.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  }

  /* ---------------------------------------------------------------- */
  /* Главный цикл анимации                                             */
  /* ---------------------------------------------------------------- */
  function tick() {
    if (!enabled) {
      rafId = 0;
      return;
    }
    const now = performance.now();
    positionLens();
    captureLoop(now);
    rafId = requestAnimationFrame(tick);
  }

  /* ---------------------------------------------------------------- */
  /* Обработчики событий страницы                                      */
  /* ---------------------------------------------------------------- */
  function onMouseMove(e) {
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursorInsideWindow = true;
  }

  /**
   * Колесико мыши:
   *  - Alt+Shift (настраив.) → яркость;
   *  - Shift (настраив.)     → зум;
   *  - иначе — страница скроллится как обычно.
   */
  function matchesCombo(comboStr, e) {
    // comboStr вида 'Alt+Shift', 'Shift', 'Ctrl', 'None'
    if (!comboStr || comboStr === 'None') return false;
    const parts = comboStr.split('+');
    const needAlt = parts.includes('Alt');
    const needCtrl = parts.includes('Ctrl');
    const needShift = parts.includes('Shift');
    return e.altKey === needAlt && e.ctrlKey === needCtrl && e.shiftKey === needShift;
  }

  function onWheel(e) {
    if (!enabled) return;

    const brightnessCombo = settings.brightnessModifiers || 'Alt+Shift';
    const zoomMod = settings.zoomModifier || 'Shift';

    const isBrightness = matchesCombo(brightnessCombo, e);
    const isZoom = !isBrightness && (zoomMod === 'None' ? true : matchesCombo(zoomMod, e));

    if (!isBrightness && !isZoom) return;

    // Страница не должна скроллиться при регулирующем колесе (ТЗ п. 5.4)
    e.preventDefault();
    e.stopPropagation();

    const dir = e.deltaY < 0 ? 1 : -1; // вверх — увеличить

    if (isBrightness) {
      const step = clampTo(settings.brightnessStep, 'brightnessStep');
      const bMin = clampTo(settings.brightnessMin, 'brightnessMin');
      const bMax = clampTo(settings.brightnessMax, 'brightnessMax');
      const next = clamp(+(brightness + dir * step).toFixed(4), bMin, bMax);
      if (next === brightness) {
        pulseBorder(); // достигнут лимит — визуальная обратная связь
      } else {
        brightness = next;
        updateIndicators();
        drawLens();
      }
    } else {
      const step = clampTo(settings.zoomStep, 'zoomStep');
      const zMin = clampTo(settings.zoomMin, 'zoomMin');
      const zMax = clampTo(settings.zoomMax, 'zoomMax');
      const next = clamp(+(zoom + dir * step).toFixed(4), zMin, zMax);
      if (next === zoom) {
        pulseBorder();
      } else {
        zoom = next;
        updateIndicators();
        drawLens();
      }
    }
  }

  /** Клик по странице скрывает лупу (ТЗ п. 3.1) */
  function onMouseDown() {
    if (enabled) deactivate();
  }

  /** Уход курсора за пределы окна — скрыть лупу (ТЗ п. 3.1 «Улучшение») */
  function onMouseLeaveWindow() {
    cursorInsideWindow = false;
  }

  function onKeyDown(e) {
    // Esc — дополнительное удобное скрытие
    if (e.key === 'Escape' && enabled) deactivate();
  }

  /* ---------------------------------------------------------------- */
  /* Активация / деактивация                                           */
  /* ---------------------------------------------------------------- */
  function activate(x, y) {
    if (!document.body) return;
    if (!root.parentNode) document.body.appendChild(root);

    // Стартовые значения — из диапазона настроек
    const zMin = clampTo(settings.zoomMin, 'zoomMin');
    const zMax = clampTo(settings.zoomMax, 'zoomMax');
    zoom = clamp(zoom, zMin, zMax);
    if (zoom < zMin) zoom = zMin;
    if (zoom > zMax) zoom = zMax;

    const bMin = clampTo(settings.brightnessMin, 'brightnessMin');
    const bMax = clampTo(settings.brightnessMax, 'brightnessMax');
    brightness = clamp(brightness, bMin, bMax);

    if (typeof x === 'number') mouseX = x;
    if (typeof y === 'number') mouseY = y;

    applySettingsToDom();
    root.hidden = false;
    enabled = true;
    cursorInsideWindow = true;
    hideMessage();

    // passive:false — нужно preventDefault на wheel (ТЗ п. 5.4)
    window.addEventListener('wheel', onWheel, { passive: false, capture: true });
    document.addEventListener('mousedown', onMouseDown, true);
    window.addEventListener('mouseleave', onMouseLeaveWindow);
    document.addEventListener('keydown', onKeyDown, true);

    updateIndicators();
    if (!rafId) rafId = requestAnimationFrame(tick);
  }

  function deactivate() {
    if (!enabled) return;
    enabled = false;
    root.hidden = true;

    window.removeEventListener('wheel', onWheel, { capture: true });
    document.removeEventListener('mousedown', onMouseDown, true);
    window.removeEventListener('mouseleave', onMouseLeaveWindow);
    document.removeEventListener('keydown', onKeyDown, true);

    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = 0;
    }
    safeSendMessage({ type: 'DEACTIVATED' });
  }

  /* ---------------------------------------------------------------- */
  /* Слушатель сообщений от service worker                             */
  /* ---------------------------------------------------------------- */
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'TOGGLE_MAGNIFIER') {
      if (msg.enable) {
        activate(mouseX, mouseY);
      } else {
        deactivate();
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* Настройки: загрузка и live-обновление                             */
  /* ---------------------------------------------------------------- */
  function loadSettings() {
    return new Promise((resolve) => {
      const fallback = Object.assign({}, DEFAULTS);
      try {
        chrome.storage.sync.get(fallback, (syncVals) => {
          if (chrome.runtime.lastError || !syncVals) {
            // Фоллбэк на local (ТЗ п. 4)
            chrome.storage.local.get(fallback, (localVals) => {
              resolve(Object.assign(fallback, localVals || {}));
            });
            return;
          }
          resolve(Object.assign(fallback, syncVals));
        });
      } catch (e) {
        resolve(fallback);
      }
    });
  }

  function normalizeSettings(raw) {
    const s = Object.assign({}, DEFAULTS, raw);

    s.size = clampTo(Number(s.size) || DEFAULTS.size, 'size');
    s.borderWidth = clampTo(Number(s.borderWidth) || DEFAULTS.borderWidth, 'borderWidth');
    s.zoomMin = clampTo(Number(s.zoomMin) || DEFAULTS.zoomMin, 'zoomMin');
    s.zoomMax = clampTo(Number(s.zoomMax) || DEFAULTS.zoomMax, 'zoomMax');
    s.zoomStep = clampTo(Number(s.zoomStep) || DEFAULTS.zoomStep, 'zoomStep');
    s.brightnessMin = clampTo(Number(s.brightnessMin) || DEFAULTS.brightnessMin, 'brightnessMin');
    s.brightnessMax = clampTo(Number(s.brightnessMax) || DEFAULTS.brightnessMax, 'brightnessMax');
    s.brightnessStep = clampTo(Number(s.brightnessStep) || DEFAULTS.brightnessStep, 'brightnessStep');

    // Sanity: min не больше max
    if (s.zoomMin > s.zoomMax) s.zoomMin = s.zoomMax;
    if (s.brightnessMin > s.brightnessMax) s.brightnessMin = s.brightnessMax;

    if (s.shape !== 'circle' && s.shape !== 'square') s.shape = 'circle';
    if (!['Shift', 'Ctrl', 'Alt', 'None'].includes(s.zoomModifier)) s.zoomModifier = 'Shift';
    if (s.borderEnabled !== false) s.borderEnabled = !!s.borderEnabled;
    if (typeof s.borderColor !== 'string' || !/^#[0-9a-fA-F]{3,8}$/.test(s.borderColor)) {
      s.borderColor = DEFAULTS.borderColor;
    }
    if (s.captureFormat !== 'png') s.captureFormat = 'jpeg';
    return s;
  }

  loadSettings().then((raw) => {
    settings = normalizeSettings(raw);
    zoom = settings.zoomMin;
    brightness = clamp(1.0,
      clampTo(settings.brightnessMin, 'brightnessMin'),
      clampTo(settings.brightnessMax, 'brightnessMax'));
    applySettingsToDom();
  });

  // Мгновенное применение изменений настроек (ТЗ п. 4)
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync' && area !== 'local') return;
      const patch = {};
      for (const key of Object.keys(changes)) {
        patch[key] = changes[key].newValue;
      }
      settings = normalizeSettings(Object.assign({}, settings, patch));
      applySettingsToDom();
      if (enabled) {
        zoom = clamp(zoom,
          clampTo(settings.zoomMin, 'zoomMin'),
          clampTo(settings.zoomMax, 'zoomMax'));
        brightness = clamp(brightness,
          clampTo(settings.brightnessMin, 'brightnessMin'),
          clampTo(settings.brightnessMax, 'brightnessMax'));
        updateIndicators();
        drawLens();
      }
    });
  } catch (e) { /* ignore */ }

  // Обновление позиции при ресайзе окна
  window.addEventListener('resize', () => {
    if (enabled) positionLens();
  });

  // Базовое отслеживание курсора работает всегда (лёгкий listener),
  // чтобы при активации лупа появилась в нужной точке
  window.addEventListener('mousemove', onMouseMove, { passive: true });
})();
