/**
 * Экранная лупа — страница настроек (options.js)
 *
 * Хранение: chrome.storage.sync с фоллбэком на chrome.storage.local (ТЗ п. 4).
 * Все изменения сохраняются и применяются мгновенно (без кнопки «Сохранить»).
 */

'use strict';

// Ключи и значения по умолчанию — должны совпадать с content/magnifier.js
const DEFAULTS = {
  shape: 'circle',
  size: 256,
  borderEnabled: true,
  borderColor: '#00AAFF',
  borderWidth: 2,
  showZoomIndicator: true,

  zoomMin: 1.5,
  zoomMax: 5.0,
  zoomStep: 0.25,
  zoomModifier: 'Shift',

  brightnessMin: 0.5,
  brightnessMax: 2.0,
  brightnessStep: 0.1,
  brightnessModifiers: 'Alt+Shift',

  smoothing: true,
  captureFormat: 'jpeg'
};

// Ограничения для клампинга вводимых значений (ТЗ п. 4)
const LIMITS = {
  size: [50, 800],
  borderWidth: [1, 10],
  zoomMin: [1.1, 10],
  zoomMax: [1.1, 10],
  zoomStep: [0.1, 1.0],
  brightnessMin: [0.1, 3],
  brightnessMax: [0.1, 3],
  brightnessStep: [0.05, 0.5]
};

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

/** Элементы формы: ключ настройки -> id/name контрола */
const CONTROLS = {
  shape: { type: 'radio', name: 'shape' },
  size: { type: 'number', id: 'size' },
  borderEnabled: { type: 'checkbox', id: 'borderEnabled' },
  borderColor: { type: 'color', id: 'borderColor' },
  borderWidth: { type: 'number', id: 'borderWidth' },
  showZoomIndicator: { type: 'checkbox', id: 'showZoomIndicator' },

  zoomMin: { type: 'number', id: 'zoomMin' },
  zoomMax: { type: 'number', id: 'zoomMax' },
  zoomStep: { type: 'number', id: 'zoomStep' },
  zoomModifier: { type: 'select', id: 'zoomModifier' },

  brightnessMin: { type: 'number', id: 'brightnessMin' },
  brightnessMax: { type: 'number', id: 'brightnessMax' },
  brightnessStep: { type: 'number', id: 'brightnessStep' },
  brightnessModifiers: { type: 'radio', name: 'brightnessModifiers' },

  smoothing: { type: 'checkbox', id: 'smoothing' }
};

/* ------------------------------------------------------------------ */
/* Чтение / запись хранилища с фоллбэком sync -> local                 */
/* ------------------------------------------------------------------ */

function storageGet(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.get(keys, (vals) => {
        if (chrome.runtime.lastError || vals === null || vals === undefined) {
          chrome.storage.local.get(keys, (localVals) => resolve(localVals || {}));
        } else {
          resolve(vals);
        }
      });
    } catch (e) {
      resolve({});
    }
  });
}

function storageSet(obj) {
  return new Promise((resolve) => {
    const done = () => resolve();
    try {
      chrome.storage.sync.set(obj, () => {
        if (chrome.runtime.lastError) {
          // sync недоступен/переполнен — пишем в local
          chrome.storage.local.set(obj, done);
        } else {
          // Синхронизируем local как зеркало для фоллбэка
          chrome.storage.local.set(obj, done);
        }
      });
    } catch (e) {
      try { chrome.storage.local.set(obj, done); } catch (_) { done(); }
    }
  });
}

/* ------------------------------------------------------------------ */
/* Отображение значений в форме                                        */
/* ------------------------------------------------------------------ */

function setControl(key, value) {
  const c = CONTROLS[key];
  if (!c) return;
  if (c.type === 'radio') {
    const radios = document.querySelectorAll(`input[name="${c.name}"]`);
    radios.forEach(r => { r.checked = (r.value === String(value)); });
  } else if (c.type === 'checkbox') {
    document.getElementById(c.id).checked = !!value;
  } else {
    document.getElementById(c.id).value = value;
  }
}

function readControl(key) {
  const c = CONTROLS[key];
  if (!c) return undefined;
  if (c.type === 'radio') {
    const checked = document.querySelector(`input[name="${c.name}"]:checked`);
    return checked ? checked.value : DEFAULTS[key];
  }
  if (c.type === 'checkbox') {
    return document.getElementById(c.id).checked;
  }
  if (c.type === 'number') {
    const raw = parseFloat(document.getElementById(c.id).value);
    const def = DEFAULTS[key];
    if (Number.isNaN(raw)) return def;
    const lim = LIMITS[key] || [-Infinity, Infinity];
    return clamp(raw, lim[0], lim[1]);
  }
  // select / color
  return document.getElementById(c.id).value;
}

/* ------------------------------------------------------------------ */
/* Взаимосвязь min/max (зум и яркость)                                 */
/* ------------------------------------------------------------------ */

function enforceRanges(values) {
  if (values.zoomMin > values.zoomMax) {
    // сдвигаем min, чтобы не нарушать ограничение max
    values.zoomMin = values.zoomMax;
    setControl('zoomMin', values.zoomMin);
  }
  if (values.brightnessMin > values.brightnessMax) {
    values.brightnessMin = values.brightnessMax;
    setControl('brightnessMin', values.brightnessMin);
  }
  return values;
}

/* ------------------------------------------------------------------ */
/* Инициализация                                                       */
/* ------------------------------------------------------------------ */

let statusTimer = 0;
function showStatus(text) {
  const el = document.getElementById('status');
  el.textContent = text;
  el.classList.add('visible');
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => el.classList.remove('visible'), 1500);
}

async function init() {
  const stored = await storageGet(Object.keys(DEFAULTS));
  const values = Object.assign({}, DEFAULTS, stored);

  for (const key of Object.keys(CONTROLS)) {
    setControl(key, values[key]);
  }

  // Мгновенное сохранение при любом изменении (ТЗ п. 4)
  const onChange = async () => {
    const next = {};
    for (const key of Object.keys(CONTROLS)) {
      next[key] = readControl(key);
    }
    enforceRanges(next);
    next.captureFormat = DEFAULTS.captureFormat;
    await storageSet(next);
    showStatus('Сохранено ✓');
  };

  document.querySelectorAll('input, select').forEach(el => {
    el.addEventListener('change', onChange);
    if (el.type === 'number') el.addEventListener('input', debounce(onChange, 300));
    if (el.type === 'color') el.addEventListener('input', debounce(onChange, 200));
  });

  document.getElementById('resetBtn').addEventListener('click', async () => {
    for (const key of Object.keys(CONTROLS)) {
      setControl(key, DEFAULTS[key]);
    }
    await storageSet(Object.assign({}, DEFAULTS));
    showStatus('Сброшено к значениям по умолчанию');
  });
}

function debounce(fn, ms) {
  let t = 0;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

init();
